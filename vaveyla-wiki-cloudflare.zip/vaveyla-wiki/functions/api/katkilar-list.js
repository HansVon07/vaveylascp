// functions/api/katkilar-list.js
//
// "Project Vaveyla" katkılarının tümünü (onaylı/onaysız) listeler.
// Herkes (giriş yapmamış ziyaretçiler dahil) okuyabilir.

function json(obj, status){
  return new Response(JSON.stringify(obj), {
    status: status || 200,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  });
}

function getBearerToken(request){
  var auth = request.headers.get('Authorization') || '';
  var m = auth.match(/^Bearer\s+(.+)$/i);
  return m ? m[1] : null;
}

async function getUserFromRequest(request, env){
  var token = getBearerToken(request);
  if (!token) return null;
  var sessRaw = await env.VAVEYLA_KV.get('session:' + token);
  if (!sessRaw) return null;
  var sess = JSON.parse(sessRaw);
  var userRaw = await env.VAVEYLA_KV.get('user:' + sess.userId);
  if (!userRaw) return null;
  return JSON.parse(userRaw);
}

export async function onRequestGet(context){
  var request = context.request;
  var env = context.env;
  if (!env.VAVEYLA_KV) return json({ error: 'Sunucu yapılandırma hatası.' }, 500);

  try {
    var user = await getUserFromRequest(request, env); // giriş yoksa null, sorun değil

    var items = [];
    var cursor;
    do {
      var list = await env.VAVEYLA_KV.list({ prefix: 'katki:', cursor: cursor });
      for (var i = 0; i < list.keys.length; i++) {
        var raw = await env.VAVEYLA_KV.get(list.keys[i].name);
        if (!raw) continue;
        var data = JSON.parse(raw);
        var oySayisi = Array.isArray(data.oylar) ? data.oylar.length : 0;
        var oyVerdiMi = !!(user && Array.isArray(data.oylar) && data.oylar.indexOf(user.id) !== -1);
        items.push({
          id: data.id,
          kategori: data.kategori,
          baslik: data.baslik,
          icerik: data.icerik,
          gorsel: data.gorsel || null,
          yazarAdi: data.yazarAdi,
          yazarId: data.yazarId,
          tarih: data.tarih,
          oySayisi: oySayisi,
          oyVerdiMi: oyVerdiMi,
          onayli: !!data.onayli,
          onaylayan: data.onaylayan || null,
        });
      }
      cursor = list.list_complete ? undefined : list.cursor;
    } while (cursor);

    items.sort(function(a, b){ return (b.tarih || 0) - (a.tarih || 0); });

    return json({ katkilar: items });
  } catch (err) {
    return json({ error: 'Beklenmeyen hata', detail: String(err) }, 500);
  }
}
