// functions/api/katkilar-onayla.js
//
// Yalnızca "admin" rolündeki kullanıcılar bir katkıyı onaylayıp resmi Lore
// statüsüne yükseltebilir (ya da onayı geri alabilir).

function json(obj, status){
  return new Response(JSON.stringify(obj), {
    status: status || 200,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  });
}

function getBearerToken(request){
  var auth = request.headers.get('Authorization') || '';
  var m = auth.match(/^Bearer\s+(.+)$/i);
  return m ? m[1] : null;
}

async function getUserFromRequest(request, env){
  var token = getBearerToken(request);
  if (!token) return null;
  var sessRaw = await env.VAVEYLA_KV.get('session:' + token);
  if (!sessRaw) return null;
  var sess = JSON.parse(sessRaw);
  var userRaw = await env.VAVEYLA_KV.get('user:' + sess.userId);
  if (!userRaw) return null;
  return JSON.parse(userRaw);
}

function isAdmin(user){
  return !!(user && Array.isArray(user.roles) && user.roles.indexOf('admin') !== -1);
}

export async function onRequestPost(context){
  var request = context.request;
  var env = context.env;
  if (!env.VAVEYLA_KV) return json({ error: 'Sunucu yapılandırma hatası.' }, 500);

  var user = await getUserFromRequest(request, env);
  if (!isAdmin(user)) return json({ error: 'Bu işlem için admin yetkisi gerekiyor.' }, 403);

  var body;
  try { body = await request.json(); } catch (e) { return json({ error: 'Geçersiz istek gövdesi.' }, 400); }

  var id = body.id;
  var onayli = !!body.onayli;
  if (!id) return json({ error: 'id gerekli.' }, 400);

  try {
    var raw = await env.VAVEYLA_KV.get('katki:' + id);
    if (!raw) return json({ error: 'Katkı bulunamadı.' }, 404);
    var item = JSON.parse(raw);

    item.onayli = onayli;
    item.onaylayan = onayli ? (user.fullName || user.email) : null;

    await env.VAVEYLA_KV.put('katki:' + id, JSON.stringify(item));

    return json({ ok: true });
  } catch (err) {
    return json({ error: 'Beklenmeyen hata', detail: String(err) }, 500);
  }
}
