// functions/api/me.js

function json(obj, status){
  return new Response(JSON.stringify(obj), {
    status: status || 200,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  });
}

function getBearerToken(request){
  var auth = request.headers.get('Authorization') || '';
  var m = auth.match(/^Bearer\s+(.+)$/i);
  return m ? m[1] : null;
}

async function getUserFromRequest(request, env){
  var token = getBearerToken(request);
  if (!token) return null;
  var sessRaw = await env.VAVEYLA_KV.get('session:' + token);
  if (!sessRaw) return null;
  var sess = JSON.parse(sessRaw);
  var userRaw = await env.VAVEYLA_KV.get('user:' + sess.userId);
  if (!userRaw) return null;
  return JSON.parse(userRaw);
}

function publicUser(user){
  return {
    sub: user.id,
    email: user.email,
    user_metadata: { full_name: user.fullName },
    app_metadata: { roles: user.roles || [] },
  };
}

export async function onRequestGet(context){
  var request = context.request;
  var env = context.env;
  if (!env.VAVEYLA_KV) return json({ error: 'Sunucu yapılandırma hatası.' }, 500);

  try {
    var user = await getUserFromRequest(request, env);
    if (!user) return json({ error: 'Oturum bulunamadı.' }, 401);
    return json({ user: publicUser(user) });
  } catch (err) {
    return json({ error: 'Beklenmeyen hata', detail: String(err) }, 500);
  }
}
