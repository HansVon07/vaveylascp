// functions/api/katkilar-vote.js
//
// Giriş yapmış bir kullanıcının bir katkıya +1 vermesini/geri almasını sağlar.
// Aynı kullanıcı bir katkıya yalnızca bir kez oy verebilir (tekrar tıklarsa oyu geri alınır).

function json(obj, status){
  return new Response(JSON.stringify(obj), {
    status: status || 200,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  });
}

function getBearerToken(request){
  var auth = request.headers.get('Authorization') || '';
  var m = auth.match(/^Bearer\s+(.+)$/i);
  return m ? m[1] : null;
}

async function getUserFromRequest(request, env){
  var token = getBearerToken(request);
  if (!token) return null;
  var sessRaw = await env.VAVEYLA_KV.get('session:' + token);
  if (!sessRaw) return null;
  var sess = JSON.parse(sessRaw);
  var userRaw = await env.VAVEYLA_KV.get('user:' + sess.userId);
  if (!userRaw) return null;
  return JSON.parse(userRaw);
}

export async function onRequestPost(context){
  var request = context.request;
  var env = context.env;
  if (!env.VAVEYLA_KV) return json({ error: 'Sunucu yapılandırma hatası.' }, 500);

  var user = await getUserFromRequest(request, env);
  if (!user) return json({ error: 'Oy vermek için giriş yapmalısınız.' }, 401);

  var body;
  try { body = await request.json(); } catch (e) { return json({ error: 'Geçersiz istek gövdesi.' }, 400); }

  var id = body.id;
  if (!id) return json({ error: 'id gerekli.' }, 400);

  try {
    var raw = await env.VAVEYLA_KV.get('katki:' + id);
    if (!raw) return json({ error: 'Katkı bulunamadı.' }, 404);
    var item = JSON.parse(raw);

    item.oylar = Array.isArray(item.oylar) ? item.oylar : [];
    var uid = user.id;
    var idx = item.oylar.indexOf(uid);
    var oyVerdiMi;
    if (idx === -1) {
      item.oylar.push(uid);
      oyVerdiMi = true;
    } else {
      item.oylar.splice(idx, 1);
      oyVerdiMi = false;
    }

    await env.VAVEYLA_KV.put('katki:' + id, JSON.stringify(item));

    return json({ ok: true, oySayisi: item.oylar.length, oyVerdiMi: oyVerdiMi });
  } catch (err) {
    return json({ error: 'Beklenmeyen hata', detail: String(err) }, 500);
  }
}
