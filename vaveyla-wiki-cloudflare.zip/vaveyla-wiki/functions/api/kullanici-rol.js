// functions/api/kullanici-rol.js
//
// Yalnızca "admin" rolündeki kullanıcılar için: bir kullanıcıya "admin" ya da
// "yetkili" rolü ekler/kaldırır. Netlify Identity kullanılırken bu işlem
// Netlify'ın kendi panelinden yapılıyordu; artık dashboard olmadığı için bu
// site içi endpoint üzerinden yapılıyor.

function json(obj, status){
  return new Response(JSON.stringify(obj), {
    status: status || 200,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  });
}

function getBearerToken(request){
  var auth = request.headers.get('Authorization') || '';
  var m = auth.match(/^Bearer\s+(.+)$/i);
  return m ? m[1] : null;
}

async function getUserFromRequest(request, env){
  var token = getBearerToken(request);
  if (!token) return null;
  var sessRaw = await env.VAVEYLA_KV.get('session:' + token);
  if (!sessRaw) return null;
  var sess = JSON.parse(sessRaw);
  var userRaw = await env.VAVEYLA_KV.get('user:' + sess.userId);
  if (!userRaw) return null;
  return JSON.parse(userRaw);
}

function isAdmin(user){
  return !!(user && Array.isArray(user.roles) && user.roles.indexOf('admin') !== -1);
}

export async function onRequestPost(context){
  var request = context.request;
  var env = context.env;
  if (!env.VAVEYLA_KV) return json({ error: 'Sunucu yapılandırma hatası.' }, 500);

  var admin = await getUserFromRequest(request, env);
  if (!isAdmin(admin)) return json({ error: 'Bu işlem için admin yetkisi gerekiyor.' }, 403);

  var body;
  try { body = await request.json(); } catch (e) { return json({ error: 'Geçersiz istek gövdesi.' }, 400); }

  var id = body.id;
  var role = body.role;
  var action = body.action; // 'add' | 'remove'

  if (!id || ['admin', 'yetkili'].indexOf(role) === -1 || ['add', 'remove'].indexOf(action) === -1) {
    return json({ error: 'Geçersiz istek.' }, 400);
  }

  try {
    var raw = await env.VAVEYLA_KV.get('user:' + id);
    if (!raw) return json({ error: 'Kullanıcı bulunamadı.' }, 404);
    var u = JSON.parse(raw);
    u.roles = Array.isArray(u.roles) ? u.roles : [];
    var idx = u.roles.indexOf(role);

    if (action === 'add' && idx === -1) u.roles.push(role);
    if (action === 'remove' && idx !== -1) u.roles.splice(idx, 1);

    await env.VAVEYLA_KV.put('user:' + id, JSON.stringify(u));

    return json({ ok: true, roller: u.roles });
  } catch (err) {
    return json({ error: 'Beklenmeyen hata', detail: String(err) }, 500);
  }
}
