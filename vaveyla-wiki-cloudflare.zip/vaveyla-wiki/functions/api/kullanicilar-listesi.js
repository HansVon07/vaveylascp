// functions/api/kullanicilar-listesi.js
//
// Yalnızca "admin" rolündeki kullanıcılar için: sitede kayıtlı TÜM hesapları
// (rolden bağımsız) listeler. Admin panelinde kullanılır.

function json(obj, status){
  return new Response(JSON.stringify(obj), {
    status: status || 200,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  });
}

function getBearerToken(request){
  var auth = request.headers.get('Authorization') || '';
  var m = auth.match(/^Bearer\s+(.+)$/i);
  return m ? m[1] : null;
}

async function getUserFromRequest(request, env){
  var token = getBearerToken(request);
  if (!token) return null;
  var sessRaw = await env.VAVEYLA_KV.get('session:' + token);
  if (!sessRaw) return null;
  var sess = JSON.parse(sessRaw);
  var userRaw = await env.VAVEYLA_KV.get('user:' + sess.userId);
  if (!userRaw) return null;
  return JSON.parse(userRaw);
}

function isAdmin(user){
  return !!(user && Array.isArray(user.roles) && user.roles.indexOf('admin') !== -1);
}

export async function onRequestGet(context){
  var request = context.request;
  var env = context.env;
  if (!env.VAVEYLA_KV) return json({ error: 'Sunucu yapılandırma hatası.' }, 500);

  var user = await getUserFromRequest(request, env);
  if (!isAdmin(user)) return json({ error: 'Bu işlem için admin yetkisi gerekiyor.' }, 403);

  try {
    var kullanicilar = [];
    var cursor;
    do {
      var list = await env.VAVEYLA_KV.list({ prefix: 'user:', cursor: cursor });
      for (var i = 0; i < list.keys.length; i++) {
        var raw = await env.VAVEYLA_KV.get(list.keys[i].name);
        if (!raw) continue;
        var u = JSON.parse(raw);
        kullanicilar.push({
          id: u.id,
          email: u.email,
          isim: u.fullName || '',
          roller: u.roles || [],
          olusturulma: u.createdAt,
          sonGiris: u.lastLogin || null,
          onaylandi: !!u.confirmed,
        });
      }
      cursor = list.list_complete ? undefined : list.cursor;
    } while (cursor);

    kullanicilar.sort(function(a, b){ return (b.olusturulma || 0) - (a.olusturulma || 0); });

    return json({ kullanicilar: kullanicilar });
  } catch (err) {
    return json({ error: 'Beklenmeyen hata', detail: String(err) }, 500);
  }
}
