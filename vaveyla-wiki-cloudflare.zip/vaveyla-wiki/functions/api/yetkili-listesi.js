// functions/api/yetkili-listesi.js
//
// Herkese açık: rolü "admin" veya "yetkili" olan kullanıcıların adını ve
// rolünü listeler (Yetkili Kadrosu sayfası için).

function json(obj, status, extraHeaders){
  var headers = { 'Content-Type': 'application/json' };
  if (extraHeaders) { for (var k in extraHeaders) headers[k] = extraHeaders[k]; }
  return new Response(JSON.stringify(obj), { status: status || 200, headers: headers });
}

export async function onRequestGet(context){
  var env = context.env;
  if (!env.VAVEYLA_KV) return json({ error: 'Sunucu yapılandırma hatası.' }, 500);

  try {
    var yetkililer = [];
    var cursor;
    do {
      var list = await env.VAVEYLA_KV.list({ prefix: 'user:', cursor: cursor });
      for (var i = 0; i < list.keys.length; i++) {
        var raw = await env.VAVEYLA_KV.get(list.keys[i].name);
        if (!raw) continue;
        var u = JSON.parse(raw);
        var roles = u.roles || [];
        if (roles.indexOf('admin') !== -1 || roles.indexOf('yetkili') !== -1) {
          yetkililer.push({
            name: u.fullName || u.email || 'İsimsiz Kullanıcı',
            role: roles.indexOf('admin') !== -1 ? 'Admin' : 'Yetkili',
          });
        }
      }
      cursor = list.list_complete ? undefined : list.cursor;
    } while (cursor);

    yetkililer.sort(function(a, b){
      if (a.role !== b.role) return a.role === 'Admin' ? -1 : 1;
      return a.name.localeCompare(b.name, 'tr');
    });

    return json({ yetkililer: yetkililer }, 200, { 'Cache-Control': 'public, max-age=60' });
  } catch (err) {
    return json({ error: 'Beklenmeyen hata', detail: String(err) }, 500);
  }
}
