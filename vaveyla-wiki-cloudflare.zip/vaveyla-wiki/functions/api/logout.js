// functions/api/logout.js

function json(obj, status){
  return new Response(JSON.stringify(obj), {
    status: status || 200,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  });
}

function getBearerToken(request){
  var auth = request.headers.get('Authorization') || '';
  var m = auth.match(/^Bearer\s+(.+)$/i);
  return m ? m[1] : null;
}

export async function onRequestPost(context){
  var request = context.request;
  var env = context.env;
  try {
    var token = getBearerToken(request);
    if (token && env.VAVEYLA_KV) {
      await env.VAVEYLA_KV.delete('session:' + token);
    }
    return json({ ok: true });
  } catch (err) {
    return json({ ok: true }); // çıkış her koşulda başarılı sayılır
  }
}
