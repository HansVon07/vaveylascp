// functions/api/katkilar-create.js
//
// Giriş yapmış bir kullanıcının "Project Vaveyla" için yeni bir katkı
// (Özel SCP / Lore Katkısı / Departmanlar / Çıkar Grupları / Diğer) göndermesini sağlar.

var KATEGORILER = ['Özel SCP', 'Lore Katkısı', 'Departmanlar', 'Çıkar Grupları', 'Diğer'];
var MAX_BASLIK = 150;
var MAX_ICERIK = 20000;
var MAX_GORSEL_BYTES = 4.5 * 1024 * 1024;

function json(obj, status){
  return new Response(JSON.stringify(obj), {
    status: status || 200,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  });
}

function getBearerToken(request){
  var auth = request.headers.get('Authorization') || '';
  var m = auth.match(/^Bearer\s+(.+)$/i);
  return m ? m[1] : null;
}

async function getUserFromRequest(request, env){
  var token = getBearerToken(request);
  if (!token) return null;
  var sessRaw = await env.VAVEYLA_KV.get('session:' + token);
  if (!sessRaw) return null;
  var sess = JSON.parse(sessRaw);
  var userRaw = await env.VAVEYLA_KV.get('user:' + sess.userId);
  if (!userRaw) return null;
  return JSON.parse(userRaw);
}

export async function onRequestPost(context){
  var request = context.request;
  var env = context.env;
  if (!env.VAVEYLA_KV) return json({ error: 'Sunucu yapılandırma hatası.' }, 500);

  var user = await getUserFromRequest(request, env);
  if (!user) return json({ error: 'Katkı göndermek için giriş yapmalısınız.' }, 401);

  var body;
  try { body = await request.json(); } catch (e) { return json({ error: 'Geçersiz istek gövdesi.' }, 400); }

  var kategori = (body.kategori || '').trim();
  var baslik = (body.baslik || '').trim();
  var icerik = (body.icerik || '').trim();
  var gorsel = body.gorsel || null;

  if (KATEGORILER.indexOf(kategori) === -1) {
    return json({ error: 'Geçersiz konu seçildi.' }, 400);
  }
  if (!baslik || baslik.length > MAX_BASLIK) {
    return json({ error: 'Başlık gerekli (en fazla ' + MAX_BASLIK + ' karakter).' }, 400);
  }
  if (!icerik || icerik.length > MAX_ICERIK) {
    return json({ error: 'Metin gerekli (en fazla ' + MAX_ICERIK + ' karakter).' }, 400);
  }
  if (gorsel) {
    if (typeof gorsel !== 'string' || !/^data:image\/(png|jpe?g|webp|gif);base64,/.test(gorsel)) {
      return json({ error: 'Geçersiz görsel formatı.' }, 400);
    }
    if (gorsel.length > MAX_GORSEL_BYTES) {
      return json({ error: 'Görsel çok büyük. Lütfen daha küçük bir görsel seçin.' }, 400);
    }
  }

  var id = crypto.randomUUID();
  var item = {
    id: id,
    kategori: kategori,
    baslik: baslik,
    icerik: icerik,
    gorsel: gorsel,
    yazarId: user.id,
    yazarAdi: user.fullName || user.email || 'İsimsiz Kullanıcı',
    tarih: Date.now(),
    oylar: [],
    onayli: false,
    onaylayan: null,
  };

  try {
    await env.VAVEYLA_KV.put('katki:' + id, JSON.stringify(item));
    return json({ ok: true, id: id });
  } catch (err) {
    return json({ error: 'Kaydedilirken hata oluştu', detail: String(err) }, 500);
  }
}
