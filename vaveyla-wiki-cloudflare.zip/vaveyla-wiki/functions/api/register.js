// functions/api/register.js
//
// Yeni kullanıcı kaydı. Şifre asla düz metin olarak saklanmaz; PBKDF2 (SHA-256,
// 100.000 iterasyon, rastgele salt) ile hash'lenip Cloudflare Workers KV'ye yazılır.
// Sitedeki İLK kayıt olan kullanıcı otomatik olarak "admin" rolünü alır
// (Netlify Identity'deki manuel rol atama panelinin yerini tutar).

function json(obj, status){
  return new Response(JSON.stringify(obj), {
    status: status || 200,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  });
}

function bytesToHex(bytes){
  return Array.from(bytes).map(function(b){ return b.toString(16).padStart(2, '0'); }).join('');
}
function hexToBytes(hex){
  var arr = new Uint8Array(hex.length / 2);
  for (var i = 0; i < arr.length; i++) arr[i] = parseInt(hex.substr(i * 2, 2), 16);
  return arr;
}

async function hashPassword(password, saltHex){
  var enc = new TextEncoder();
  var salt = saltHex ? hexToBytes(saltHex) : crypto.getRandomValues(new Uint8Array(16));
  var keyMaterial = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  var bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', hash: 'SHA-256', salt: salt, iterations: 100000 },
    keyMaterial,
    256
  );
  return { hash: bytesToHex(new Uint8Array(bits)), salt: bytesToHex(salt) };
}

async function createSession(env, userId){
  var token = crypto.randomUUID() + crypto.randomUUID();
  await env.VAVEYLA_KV.put('session:' + token, JSON.stringify({ userId: userId }), {
    expirationTtl: 60 * 60 * 24 * 30, // 30 gün
  });
  return token;
}

function publicUser(user){
  return {
    sub: user.id,
    email: user.email,
    user_metadata: { full_name: user.fullName },
    app_metadata: { roles: user.roles || [] },
  };
}

export async function onRequestPost(context){
  var request = context.request;
  var env = context.env;

  if (!env.VAVEYLA_KV) {
    return json({ error: 'Sunucu yapılandırma hatası: VAVEYLA_KV bağlantısı bulunamadı. Cloudflare Pages ayarlarından KV namespace bağlamayı unutmayın.' }, 500);
  }

  var body;
  try { body = await request.json(); } catch (e) { return json({ error: 'Geçersiz istek gövdesi.' }, 400); }

  var email = (body.email || '').trim().toLowerCase();
  var password = body.password || '';
  var fullName = (body.fullName || '').trim().slice(0, 80);

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return json({ error: 'Geçerli bir e-posta adresi girin.' }, 400);
  }
  if (password.length < 8) {
    return json({ error: 'Şifre en az 8 karakter olmalı.' }, 400);
  }
  if (!fullName) {
    return json({ error: 'Ad soyad girin.' }, 400);
  }

  try {
    var idxKey = 'useridx:' + email;
    var existing = await env.VAVEYLA_KV.get(idxKey);
    if (existing) {
      return json({ error: 'Bu e-posta ile zaten bir hesap var.' }, 400);
    }

    // Bootstrap: hiç kullanıcı yoksa ilk kayıt olan otomatik admin olur.
    var existingUsers = await env.VAVEYLA_KV.list({ prefix: 'user:', limit: 1 });
    var isFirstUser = existingUsers.keys.length === 0;

    var hashed = await hashPassword(password);
    var id = crypto.randomUUID();
    var user = {
      id: id,
      email: email,
      passwordHash: hashed.hash,
      salt: hashed.salt,
      fullName: fullName,
      roles: isFirstUser ? ['admin'] : [],
      createdAt: Date.now(),
      lastLogin: Date.now(),
      confirmed: true,
    };

    await env.VAVEYLA_KV.put('user:' + id, JSON.stringify(user));
    await env.VAVEYLA_KV.put(idxKey, id);

    var token = await createSession(env, id);
    return json({ ok: true, token: token, user: publicUser(user) });
  } catch (err) {
    return json({ error: 'Kayıt sırasında hata oluştu.', detail: String(err) }, 500);
  }
}
