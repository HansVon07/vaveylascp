// functions/api/login.js

function json(obj, status){
  return new Response(JSON.stringify(obj), {
    status: status || 200,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  });
}

function bytesToHex(bytes){
  return Array.from(bytes).map(function(b){ return b.toString(16).padStart(2, '0'); }).join('');
}
function hexToBytes(hex){
  var arr = new Uint8Array(hex.length / 2);
  for (var i = 0; i < arr.length; i++) arr[i] = parseInt(hex.substr(i * 2, 2), 16);
  return arr;
}

async function hashPassword(password, saltHex){
  var enc = new TextEncoder();
  var salt = saltHex ? hexToBytes(saltHex) : crypto.getRandomValues(new Uint8Array(16));
  var keyMaterial = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  var bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', hash: 'SHA-256', salt: salt, iterations: 100000 },
    keyMaterial,
    256
  );
  return { hash: bytesToHex(new Uint8Array(bits)), salt: bytesToHex(salt) };
}

async function createSession(env, userId){
  var token = crypto.randomUUID() + crypto.randomUUID();
  await env.VAVEYLA_KV.put('session:' + token, JSON.stringify({ userId: userId }), {
    expirationTtl: 60 * 60 * 24 * 30,
  });
  return token;
}

function publicUser(user){
  return {
    sub: user.id,
    email: user.email,
    user_metadata: { full_name: user.fullName },
    app_metadata: { roles: user.roles || [] },
  };
}

export async function onRequestPost(context){
  var request = context.request;
  var env = context.env;

  if (!env.VAVEYLA_KV) {
    return json({ error: 'Sunucu yapılandırma hatası: VAVEYLA_KV bağlantısı bulunamadı.' }, 500);
  }

  var body;
  try { body = await request.json(); } catch (e) { return json({ error: 'Geçersiz istek gövdesi.' }, 400); }

  var email = (body.email || '').trim().toLowerCase();
  var password = body.password || '';
  if (!email || !password) {
    return json({ error: 'E-posta ve şifre gerekli.' }, 400);
  }

  try {
    var id = await env.VAVEYLA_KV.get('useridx:' + email);
    if (!id) return json({ error: 'E-posta veya şifre hatalı.' }, 401);

    var userRaw = await env.VAVEYLA_KV.get('user:' + id);
    if (!userRaw) return json({ error: 'E-posta veya şifre hatalı.' }, 401);
    var user = JSON.parse(userRaw);

    var hashed = await hashPassword(password, user.salt);
    if (hashed.hash !== user.passwordHash) {
      return json({ error: 'E-posta veya şifre hatalı.' }, 401);
    }

    user.lastLogin = Date.now();
    await env.VAVEYLA_KV.put('user:' + id, JSON.stringify(user));

    var token = await createSession(env, id);
    return json({ ok: true, token: token, user: publicUser(user) });
  } catch (err) {
    return json({ error: 'Giriş sırasında hata oluştu.', detail: String(err) }, 500);
  }
}
